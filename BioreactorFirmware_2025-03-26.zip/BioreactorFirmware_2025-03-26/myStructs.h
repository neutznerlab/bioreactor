#ifndef yyStructs_h
#define myStructs_h

//what type of protocol are we running - protocolType
//0 - we do not run a protocol
//1 - we run a protocol
//2 - we run a volt/frequency protocol
//pressure:  1,26,3,8,6,12,0,0,0,0,0,0,5,8,10
//volt/freq: 2,26,3,8,6,12,100,150,200,100,200,300,-1,-1,-1,
//use a struct to store the protocol
typedef struct{
  byte protocolType;
  unsigned long protocolTotalDuration;
  byte stepsInProtocol;
  unsigned long protocolStepDuration[100];
  int protocolVoltage[100];
  int protocolFrequency[100];
  float protocolPressure[100];
  } protocol;


typedef struct{
    unsigned long protoStartTimeStamp; //a unix time stamp supplied by the GUI
    unsigned long hibernationTimeOffset; //time in seconds lost during hibernation - supplied by GUI
    unsigned long hibTSON; //a unix time stamp - detachment started
    unsigned long hibTSOFF; //a unix time stamp - detachment ended
    unsigned long protoTotalTime; //total runtime of the protocol in seconds - timer contents
    unsigned long protoIterationTime; //time in the current iteration of the protocol
    unsigned long protocolRepeat; // how often did we go through the protocol
    byte protocolStep; //in which step of the protocol are we currently
    unsigned long protoStepTime; //time in the current step
    boolean protocolRunning; //1 - protocol is active
    boolean modelHibernated; //1 - protocol is active but hibernated
    int currentVoltage;
    int currentFrequency;
    float currentPressure;
  } modelStatus;
  
#endif
